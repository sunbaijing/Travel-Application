const request = require("request");

const forecast = (latitude, longitude, date, callback) => {
  const API_KEY = "6f22e0878fa183b0846d9321f908a23a";
  const url = `https://api.darksky.net/forecast/${API_KEY}/${encodeURIComponent(latitude)},${encodeURIComponent(longitude)},${encodeURIComponent(date)}`;
  request({ url, json: true }, (error, { body }) => {
    if (error) {
      callback(`No internet connection`, undefined);
    } else if (body.error) {
      callback("Date is needed", undefined);
    } else {
      callback(
        error,
        `${body.daily.data[0].summary} It will be ${body.currently.apparentTemperature} degrees out. There is ${body.currently.precipProbability} chance of rain`
      );
    }
  });
};

module.exports = forecast;
