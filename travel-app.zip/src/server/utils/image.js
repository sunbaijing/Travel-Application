const request = require("request");

const image = (location, callback) => {
  const API_KEY = "15043010-cad397e6dd07443d040b4bc06";
  const url = `https://pixabay.com/api/?key=${API_KEY}&q=${encodeURIComponent(location)}&image_type=photo`;
  request({ url, json: true }, (error, { body }) => {
    if (error) {
      callback(`No internet connection`, undefined);
    } else if (body.error) {
      callback("Location unknown", undefined);
    } else {
      if (body.hits.length === 0) {
        callback(error, "");
      } else {
        callback(error, body.hits[0].previewURL);
        console.log(body.hits[0].previewURL);
      }
    }
  });
};
module.exports = image;