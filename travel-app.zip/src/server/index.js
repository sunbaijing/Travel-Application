// Setup empty JS object to act as endpoint for all routes
const express = require("express");
const bodyParser = require("body-parser");
const forecast = require("./utils/forecast");
const geocode = require("./utils/geocode");
const image = require("./utils/image");
const cors = require("cors");

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());
app.use(express.static("dist"));

app.get("/", (req, res) => {
  res.sendFile("dist/index.html");
});

app.get("/forecast", (req, res) => {
  //If user did not enter address. It will send an error that requires adress
  if (!req.query.address) {
    return res.send({
      error: "Address and date must be provided"
    });
  } else {
    //`http://localhost:8080/forecast?address=${address}&date=${unixDate}`)/   
    geocode(req.query.address, (error, { latitude, longtitude, location }) => {
      if (error) {
        return res.send({
          error: error
        });
      } else {
        forecast(
          latitude,
          longtitude,
          req.query.date,
          (error, forecastData) => {
            if (error) {
              return res.send({
                error: error
              });
            } else {
              image(req.query.address, (error, image) => {
                if (error) {
                  return res.send({
                    error
                  });
                } else {
                  const date = req.query.date;
                  res.send({
                    latitude,
                    longtitude,
                    image,
                    location,
                    forecastData,
                    date
                  });
                }
              });
            }
          }
        );
      }
    });
  }
});

app.get("*", (req, res) => {
  res.send("Error");
});

const port = 8080;

app.listen(port, () => {
  console.log("App listening on port " + port);
});
