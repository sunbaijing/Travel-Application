const messageOne = document.querySelector(".location");
const messageTwo = document.querySelector(".forecast-data");
const image = document.querySelector(".image");
const location = document.querySelector(".city-text");
const date = document.querySelector(".date");

const fetchAPI = () => {
  const unixDate = new Date(date.value).getTime() / 1000;
  const address = location.value;
  fetch(`http://localhost:8080/forecast?address=${encodeURI(address)}&date=${unixDate}`)
    .then(res => {
      console.log(res);

      return res.json();
    })
    .then(res => {
      if (res.error) {
        messageOne.textContent = res.error;
      } else {
        const date = new Date(res.date * 1000);
        const month = date.getMonth() + 1;
        const day = date.getDate() + 1;
        const year = date.getFullYear();

        messageOne.textContent = `Awesome, you are travelling to ${res.location} on ${month}/${day}/${year}, 
         and location is (${res.latitude},${res.longtitude}).`;
        messageTwo.textContent = `The weather is: ${res.forecastData}`;
        image.src = res.image;
      }
    });
};

export default fetchAPI;
