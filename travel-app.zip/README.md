# Travel App Project

## Overview
I hope my current project could update the geonames information(including latitude, longitude and country) through cobination all the parts of the project.

## Instructions(run the projects)
first, type npm install
second, npm run build and then npm run build-prod
next, open another cmd command and type npm run build-dev
## Results
The results will give the date, the location name, and the coordinate details, 
the weather condition and local images
